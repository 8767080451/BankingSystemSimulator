package exceptions;
public class WithdrawTransaction extends Transaction {
    public WithdrawTransaction(Bank bank, String accNo, double amount) {
        super(bank, accNo, amount);
    }

    @Override
    public void run() {
        try {
            bank.withdraw(accountNumber, amount);
            System.out.println(Thread.currentThread().getName() +
                    " withdrew " + amount + " from " + accountNumber);
        } catch (Exception e) {
            System.out.println("Withdrawal failed: " + e.getMessage());
        }
    }
}
