===========================================================
            BANKING SYSTEM SIMULATOR (Core Java)
===========================================================

👤 Developer: Chaitanya Vijay Chaudhari  
🎓 Java FSD @Virtusa Batch 1 [Mini Project 1]
📅 Education & Year: B.E IT [2021 - 2025]
💻 Language Used: Core Java (OOPs, Collections, Threads)

-----------------------------------------------------------
📌 Project Overview
-----------------------------------------------------------
This Banking System Simulator is a console-based Java application 
that allows users to perform basic banking operations like:

1. Account Creation  
2. Deposit  
3. Withdraw  
4. Fund Transfer  
5. Balance Inquiry  

The system stores multiple accounts using Java Collections and 
handles concurrent transactions using multithreading. It also 
includes robust exception handling for invalid inputs or operations.

-----------------------------------------------------------
🧠 Key Concepts Used
-----------------------------------------------------------
1] Object-Oriented Programming (Encapsulation, Abstraction)  
2] Collections Framework (HashMap, Generics)  
3] Exception Handling (Custom Exceptions)  
4] Functional Programming (Streams and Lambdas)  
5] Multithreading with Synchronization  
6] Menu-driven console interface

-----------------------------------------------------------
⚙️ How to Run
-----------------------------------------------------------
1. Open the project in Eclipse IDE.
2. Ensure the folder structure:
   BankingSystemSimulator
   └── src
       ├── banking
       │   ├── Account.java
       │   ├── Bank.java
       │   └── Main.java   ← Run this file
       └── exceptions
           ├── InvalidAmountException.java
           ├── InsufficientBalanceException.java
           ├── InvalidNameException.java
           └── AccountNotFoundException.java
3. Right-click on `Main.java` → Run As → Java Application.
4. Follow the on-screen menu to perform operations.

-----------------------------------------------------------
🧩 Example Input/Output
-----------------------------------------------------------

===== Banking System Simulator =====
1. Create Account
2. Deposit
3. Withdraw
4. Transfer
5. Show Balance
6. Exit
Enter your choice: 1
Enter account holder name: Chaitanya
✅ Account created successfully!
Account Number: CH1234

-----------------------------------------------------------
💡 Sample Exceptions Handled
-----------------------------------------------------------
- InvalidNameException: Empty or null name
- InvalidAmountException: Deposit/withdraw amount ≤ 0
- InsufficientBalanceException: Withdrawal exceeds balance
- AccountNotFoundException: Invalid account number
- InputMismatchException: Wrong data type entered by users

-----------------------------------------------------------
🧮 Evaluation Highlights
-----------------------------------------------------------
✔ Account class well-structured (Encapsulation)  
✔ Collections with Generics used for account management  
✔ Streams used for filtering/searching  
✔ Multithreading used to handle simultaneous transactions  
✔ Exception handling ensures program stability  
✔ Clean menu interface for user experience

-----------------------------------------------------------
⭐ Status: COMPLETED & TESTED SUCCESSFULLY
===========================================================
