package exceptions;
public abstract class Transaction implements Runnable {
    protected Bank bank;
    protected String accountNumber;
    protected double amount;

    public Transaction(Bank bank, String accountNumber, double amount) {
        this.bank = bank;
        this.accountNumber = accountNumber;
        this.amount = amount;
    }
}
