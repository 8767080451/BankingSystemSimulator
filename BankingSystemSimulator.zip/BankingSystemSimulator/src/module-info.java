/**
 * 
 */
/**
 * 
 */
module BankingSystemSimulator {
}