package exceptions;
public class DepositTransaction extends Transaction {
    public DepositTransaction(Bank bank, String accNo, double amount) {
        super(bank, accNo, amount);
    }

    @Override
    public void run() {
        try {
            bank.deposit(accountNumber, amount);
            System.out.println(Thread.currentThread().getName() +
                    " deposited " + amount + " into " + accountNumber);
        } catch (Exception e) {
            System.out.println("Deposit failed: " + e.getMessage());
        }
    }
}
