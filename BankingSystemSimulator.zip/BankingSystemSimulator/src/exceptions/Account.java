package exceptions;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;
import exceptions.InvalidAmountException;
import exceptions.InsufficientBalanceException;

public class Account {
    private final String accountNumber;
    private final String holderName;
    private double balance;
    private static final AtomicLong sequence = new AtomicLong(new Random().nextInt(1000));

    public Account(String holderName) {
        this.holderName = holderName;
        this.accountNumber = generateAccountNumber(holderName);
        this.balance = 0.0;
    }

    private String generateAccountNumber(String name) {
        String initials = "XX";
        if (name != null && name.trim().length() > 0) {
            String[] parts = name.trim().toUpperCase().split("\\s+");
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < Math.min(2, parts.length); i++) {
                if (parts[i].length() > 0) sb.append(parts[i].charAt(0));
            }
            initials = sb.length() > 0 ? sb.toString() : "XX";
        }
        long seq = sequence.getAndIncrement() % 10000;
        int rand = new Random().nextInt(9000) + 1000;
        return initials + rand + String.format("%04d", seq);
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public String getHolderName() {
        return holderName;
    }

    public synchronized double getBalance() {
        return balance;
    }

    public synchronized void deposit(double amount) throws InvalidAmountException {
        if (amount <= 0) throw new InvalidAmountException("Deposit amount must be positive");
        balance += amount;
    }

    public synchronized void withdraw(double amount)
            throws InvalidAmountException, InsufficientBalanceException {
        if (amount <= 0) throw new InvalidAmountException("Withdrawal amount must be positive");
        if (amount > balance)
            throw new InsufficientBalanceException("Insufficient funds. Available: " + balance);
        balance -= amount;
    }

    @Override
    public String toString() {
        return String.format("Account[number=%s, holder=%s, balance=%.2f]",
                accountNumber, holderName, balance);
    }
}
