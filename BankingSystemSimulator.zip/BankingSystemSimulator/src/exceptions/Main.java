package exceptions;
import java.util.*;
import exceptions.*;

public class Main {
    private static final Scanner sc = new Scanner(System.in);
    private static final Bank bank = new Bank();

    public static void main(String[] args) {
        System.out.println("===== Welcome to Banking System Simulator =====");
        while (true) {
            System.out.println("\nMain Menu:");
            System.out.println("1. Create Account");
            System.out.println("2. Manage Existing Account");
            System.out.println("3. Simulate Concurrent Transactions");
            System.out.println("4. Exit");

            System.out.print("Enter choice: ");
            String choice = sc.nextLine();

            switch (choice) {
                case "1" -> createAccount();
                case "2" -> manageAccount();
                case "3" -> simulateThreads();
                case "4" -> {
                    System.out.println("Goodbye!");
                    return;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    private static void createAccount() {
        try {
            System.out.print("Enter your name: ");
            String name = sc.nextLine();
            Account acc = bank.createAccount(name);
            System.out.println("Account created successfully:\n" + acc);
        } catch (InvalidNameException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void manageAccount() {
        try {
            System.out.print("Enter account number: ");
            String accNo = sc.nextLine();
            Account acc = bank.getAccount(accNo);

            while (true) {
                System.out.println("\nAccount Menu:");
                System.out.println("1. Deposit");
                System.out.println("2. Withdraw");
                System.out.println("3. Transfer");
                System.out.println("4. Show Balance");
                System.out.println("5. Back to Main Menu");
                System.out.print("Enter choice: ");
                String c = sc.nextLine();

                switch (c) {
                    case "1" -> deposit(accNo);
                    case "2" -> withdraw(accNo);
                    case "3" -> transfer(accNo);
                    case "4" -> System.out.println(acc);
                    case "5" -> { return; }
                    default -> System.out.println("Invalid choice.");
                }
            }
        } catch (AccountNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void deposit(String accNo) {
        try {
            System.out.print("Enter amount: ");
            double amt = Double.parseDouble(sc.nextLine());
            bank.deposit(accNo, amt);
            System.out.println("Deposit successful. Balance: " + bank.getAccount(accNo).getBalance());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private static void withdraw(String accNo) {
        try {
            System.out.print("Enter amount: ");
            double amt = Double.parseDouble(sc.nextLine());
            bank.withdraw(accNo, amt);
            System.out.println("Withdrawal successful. Balance: " + bank.getAccount(accNo).getBalance());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private static void transfer(String fromAcc) {
        try {
            System.out.print("Enter destination account number: ");
            String toAcc = sc.nextLine();
            System.out.print("Enter amount: ");
            double amt = Double.parseDouble(sc.nextLine());
            bank.transfer(fromAcc, toAcc, amt);
            System.out.println("Transfer successful.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private static void simulateThreads() {
        try {
            Account demo = bank.createAccount("Demo User");
            bank.deposit(demo.getAccountNumber(), 1000);
            System.out.println("Created demo account: " + demo);

            Thread t1 = new Thread(new WithdrawTransaction(bank, demo.getAccountNumber(), 500), "T1");
            Thread t2 = new Thread(new DepositTransaction(bank, demo.getAccountNumber(), 300), "T2");
            Thread t3 = new Thread(new WithdrawTransaction(bank, demo.getAccountNumber(), 700), "T3");

            t1.start(); t2.start(); t3.start();
            t1.join(); t2.join(); t3.join();

            System.out.println("Final Balance: " + demo.getBalance());
        } catch (Exception e) {
            System.out.println("Simulation failed: " + e.getMessage());
        }
    }
}
