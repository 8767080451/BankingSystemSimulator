package exceptions;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;
import exceptions.*;

public class Bank {
    private final Map<String, Account> accounts = new ConcurrentHashMap<>();

    public Account createAccount(String holderName) throws InvalidNameException {
        if (holderName == null || holderName.trim().isEmpty())
            throw new InvalidNameException("Name cannot be empty");
        Account account = new Account(holderName.trim());
        accounts.put(account.getAccountNumber(), account);
        return account;
    }

    public Account getAccount(String accNo) throws AccountNotFoundException {
        Account acc = accounts.get(accNo);
        if (acc == null) throw new AccountNotFoundException("Account not found: " + accNo);
        return acc;
    }

    public void deposit(String accNo, double amount)
            throws AccountNotFoundException, InvalidAmountException {
        Account acc = getAccount(accNo);
        acc.deposit(amount);
    }

    public void withdraw(String accNo, double amount)
            throws AccountNotFoundException, InvalidAmountException, InsufficientBalanceException {
        Account acc = getAccount(accNo);
        acc.withdraw(amount);
    }

    public void transfer(String fromAcc, String toAcc, double amount)
            throws AccountNotFoundException, InvalidAmountException, InsufficientBalanceException {
        if (fromAcc.equals(toAcc))
            throw new InvalidAmountException("Cannot transfer to same account");
        Account from = getAccount(fromAcc);
        Account to = getAccount(toAcc);

        Account firstLock = fromAcc.compareTo(toAcc) < 0 ? from : to;
        Account secondLock = firstLock == from ? to : from;

        synchronized (firstLock) {
            synchronized (secondLock) {
                from.withdraw(amount);
                to.deposit(amount);
            }
        }
    }

    public List<Account> listAccounts() {
        return new ArrayList<>(accounts.values());
    }

    public List<Account> searchByName(String keyword) {
        String key = keyword == null ? "" : keyword.toLowerCase();
        return accounts.values().stream()
                .filter(a -> a.getHolderName().toLowerCase().contains(key))
                .collect(Collectors.toList());
    }
}
